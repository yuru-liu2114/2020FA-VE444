### ...mainly look into:

1. high covertness and high transmissibility
2. probability of resurgence

### algorithm: Marko Chain Monte Carlo

- prior distribution -- belief
- likelihood distribution
- posterior distribution

Monte Carlo:

1. iteratively generate random numbers to evaluate a certain parameter
2. By generating a lot of random numbers, they can be used to model very complicated processes.

Marko chain:

1. ***memoryless\***: everything that you would possibly need to predict the next event is available in the current state, and no new information comes from knowing the history of events. 

acceptance-rejection sampling

- We are at point x.
- We make a guess for the next step. We will call this x*
- We then compute the ratio of the probability of x*/x. This is calculated using the product of the likelihood and prior distributions.
- If the ratio of p(x*)/p(x) (also called the acceptance probability) is greater than 1 we accept x* as the new position.
- Even if the acceptance probability is less than 1, we don’t automatically reject x*. We flip a coin by selecting a random number, from a Uniform(0,1) distribution. If the number is smaller than the acceptance probability we accept x* if it is higher we reject x* and start the process over again.

Put together:

- We randomly generate numbers: This is the Monte Carlo part
- We allow the numbers we generated to influence the next generated number: This is the Markov chain
- We then decide if the new numbers generated are “moving in the right direction”: The Acceptance-rejection algorithm
- We then check for convergence: We determine when our data has converged to a reasonable distribution. The randomly generated values after the convergence point become our posterior distribution

### model: SAPHIRE

### Stochastic Simulation

### Sensitivity Analysis

